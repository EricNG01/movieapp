import React, { useEffect, useState } from 'react';
import logo from './logo.svg';
import './App.css';
import Select from 'react-select';

const Searching = ({ID, type, year}) => {
  let [movieInfo, setMovieInfo] = useState(null);
  useEffect(() => {
    fetch(`http://127.0.0.1:3000/search/${ID}/${type}/${year}`)
      .then(res => { res.json() })
      .then(data => {
        console.log(data)
        setMovieInfo(data)
      })
      .catch(() => null)
	}, []);
  console.log(movieInfo)
  console.log(type)
  console.log(year)
  return (
      <div>
        Success {ID} {type} {year}
      </div>  
    )

}

function SearchByID() {
  const styles = {
    container:(base)=>({
      ...base,
      flex:1,
      width:500,
    }),
  };

  const [ID, setID] = useState("");
  const [type, setType] = useState("");
  const [year, setYear] = useState("");
  let types = [
      { value: 'movie', label: 'Movie' },
      { value: 'series', label: 'Series'},
      { value: 'episode', label: 'Episode'}
  ];

  const years = [];
  for (let index = 2023; index > 1900; index--) {
    years.push({value: index.toString(), label: index.toString()});    
  }

  const handleSubmit = (event) => {
    event.preventDefauit();
    console.log(ID)
    console.log(year)
    console.log(type)
  }

  return(
      <div >
        <h1>Movie Search</h1>
        <form onSubmit={handleSubmit}>

          <label>Enter the IMDb ID:</label>
          <div>
            <input
                type="text" 
                placeholder="e.g. enter '1234567' for id of 'tt1234567'"
                id="IMDb_ID"
                onChange = {(e) => {setID(e.target.value)}}
            />
          </div>

        <div style={{margin: "auto"}}>
          <label>Enter the IMDb ID:
            <Select
                  styles = {styles}
                  isSearchable={false}
                  isClearable={true}
                  hideSelectedOptions={true}
                  placeholder= 'Type'
                  onChange={(e) => {
                    if(!e) setType("")
                    else setType(e.value)
                  }}
                  options = {types}
            />
          </label>
        </div>

        <div style={{margin: "auto"}}>
          <label>Enter the IMDb ID:
            <Select
                  styles = {styles}
                  isSearchable = {false}
                  isClearable = {true}
                  hideSelectedOptions = {true}
                  placeholder = 'Year'
                  onChange = {(e) => {
                    if(!e) setYear("")
                    else setYear(e.value)
                  }}
                  options = {years}
            />
          </label>
        </div>
        {/* <button onClick={event => {event.preventDefault();}}>Search</button> */}
          <input type="submit"/>
        </form>        
        <div>
        <h2>{!(ID==="") && (<p id="graphTitle">The World Happiness Ranking in {ID}</p>)}</h2>
          <Searching 
            ID={ID} 
            year={year} 
            type={type}
          />
        </div>

      </div>
      
  )
}

export default function App() {
  return (
    <div>
        <SearchByID/>
    </div>        
      
  );
}

